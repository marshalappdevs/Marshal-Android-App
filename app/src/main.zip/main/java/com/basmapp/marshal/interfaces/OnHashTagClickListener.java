package com.basmapp.marshal.interfaces;

public interface OnHashTagClickListener {
    void onClick(String hashTag);
}
